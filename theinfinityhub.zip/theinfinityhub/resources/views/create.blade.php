 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<div class="container">
    <h2>Create New Product</h2>
    <form method="POST" action="{{ route('store') }}">
        @csrf

        <!-- Product Name -->
        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" required>
            @error('name')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Unit Type -->
        <div class="form-group">
            <label for="unit_type">Unit Type</label>
            <select class="form-control @error('unit_type') is-invalid @enderror" id="unit_type" name="unit_type" required>
                <option value="Qty" {{ old('unit_type') === 'Qty' ? 'selected' : '' }}>Qty</option>
                <option value="Ltr" {{ old('unit_type') === 'Ltr' ? 'selected' : '' }}>Ltr</option>
                <option value="KG" {{ old('unit_type') === 'KG' ? 'selected' : '' }}>KG</option>
                <option value="Meter" {{ old('unit_type') === 'Meter' ? 'selected' : '' }}>Meter</option>
            </select>
            @error('unit_type')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Product Price -->
        <div class="form-group">
            <label for="price">Product Price</label>
            <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}" required>
            @error('price')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Discount Percentage -->
        <div class="form-group">
            <label for="discount_percentage">Discount Percentage</label>
            <input type="number" step="0.01" class="form-control @error('discount_percentage') is-invalid @enderror" id="discount_percentage" name="discount_percentage" value="{{ old('discount_percentage') }}">
            @error('discount_percentage')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Discount Amount -->
        <div class="form-group">
            <label for="discount_amount">Discount Amount</label>
            <input type="number" step="0.01" class="form-control @error('discount_amount') is-invalid @enderror" id="discount_amount" name="discount_amount" value="{{ old('discount_amount') }}">
            @error('discount_amount')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Discount Range Dates -->
        <div class="form-group">
            <label for="discount_start_date">Discount Start Date</label>
            <input type="date" class="form-control @error('discount_start_date') is-invalid @enderror" id="discount_start_date" name="discount_start_date" value="{{ old('discount_start_date') }}">
            @error('discount_start_date')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="discount_end_date">Discount End Date</label>
            <input type="date" class="form-control @error('discount_end_date') is-invalid @enderror" id="discount_end_date" name="discount_end_date" value="{{ old('discount_end_date') }}">
            @error('discount_end_date')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Tax Percentage -->
        <div class="form-group">
            <label for="tax_percentage">Tax Percentage</label>
            <input type="number" step="0.01" class="form-control @error('tax_percentage') is-invalid @enderror" id="tax_percentage" name="tax_percentage" value="{{ old('tax_percentage') }}">
            @error('tax_percentage')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Tax Amount -->
        <div class="form-group">
            <label for="tax_amount">Tax Amount</label>
            <input type="number" step="0.01" class="form-control @error('tax_amount') is-invalid @enderror" id="tax_amount" name="tax_amount" value="{{ old('tax_amount') }}">
            @error('tax_amount')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Stock Quantity -->
        <div class="form-group">
            <label for="stock_quantity">Stock Quantity</label>
            <input type="number" class="form-control @error('stock_quantity') is-invalid @enderror" id="stock_quantity" name="stock_quantity" value="{{ old('stock_quantity') }}">
            @error('stock_quantity')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Add fields for other product attributes here -->

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Create Product</button>
    </form>
</div>