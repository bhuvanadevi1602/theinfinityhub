<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <!-- Include your CSS and JavaScript files here -->
</head>
<body>
    <header>
        <!-- Navigation menu, logo, or any common header content -->
    </header>

    <main>
        @yield('content') <!-- Child views will inject content here -->
    </main>

    <footer>
        <!-- Footer content -->
    </footer>
</body>
</html>
