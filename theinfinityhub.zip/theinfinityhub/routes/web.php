<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::resource('products', 'App\Http\Controllers\ProductController');
Route::get('/index', 'App\Http\Controllers\ProductController@index')->name('index');
Route::get('/create', 'App\Http\Controllers\ProductController@create')->name('create');
Route::post('/store', 'App\Http\Controllers\ProductController@store')->name('store');
Route::get('/edit/{id}', 'App\Http\Controllers\ProductController@edit')->name('edit');
Route::put('/update/{id}', 'App\Http\Controllers\ProductController@update')->name('update');
Route::delete('/destroy/{id}', 'App\Http\Controllers\ProductController@destroy')->name('destroy');

