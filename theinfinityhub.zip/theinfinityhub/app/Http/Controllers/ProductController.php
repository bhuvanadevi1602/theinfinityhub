<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('index', compact('products'));
    }

    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'unit_type' => 'required|in:Qty,Ltr,KG,Meter',
            'price' => 'required|numeric|min:0.01',
            'discount_percentage' => 'nullable|numeric|min:0|max:100',
            'discount_amount' => 'nullable|numeric|min:0',
            'discount_start_date' => 'nullable|date',
            'discount_end_date' => 'nullable|date|after_or_equal:discount_start_date',
            'tax_percentage' => 'nullable|numeric|min:0|max:100',
            'tax_amount' => 'nullable|numeric|min:0',
            'stock_quantity' => 'nullable|integer|min:0',
        ]);

        $product = new Product;
        $product->name = $validatedData['name'];
        $product->unit_type = $validatedData['unit_type'];
        $product->price = $validatedData['price'];
        $product->discount_percentage = $validatedData['discount_percentage'];
        $product->discount_amount = $validatedData['discount_amount'];
        $product->discount_start_date = $validatedData['discount_start_date'];
        $product->discount_end_date = $validatedData['discount_end_date'];
        $product->tax_percentage = $validatedData['tax_percentage'];
        $product->tax_amount = $validatedData['tax_amount'];
        $product->stock_quantity = $validatedData['stock_quantity'];

        $product->save();

        return redirect()->route('index')->with('success', 'Product created successfully');
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        return view('edit', compact('product'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'unit_type' => 'required|in:Qty,Ltr,KG,Meter',
        ]);

        $product = Product::findOrFail($id);

        $product->name = $request->input('name');
        $product->unit_type = $request->input('unit_type');
        $product->price = $request->input('price');
        $product->discount_percentage = $request->input('discount_percentage');
        $product->discount_amount = $request->input('discount_amount');
        $product->discount_start_date = $request->input('discount_start_date');
        $product->discount_end_date = $request->input('discount_end_date');
        $product->tax_percentage = $request->input('tax_percentage');
        $product->tax_amount = $request->input('tax_amount');
        $product->stock_quantity = $request->input('stock_quantity');

        $product->save();

        return redirect()->route('index')->with('success', 'Product updated successfully');
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        $product->delete();

        return redirect()->route('index')->with('success', 'Product deleted successfully');
    }
}
